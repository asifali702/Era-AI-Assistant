# Add project specific ProGuard rules here.
# Keep Compose and Kotlin metadata.
-keepattributes *Annotation*
