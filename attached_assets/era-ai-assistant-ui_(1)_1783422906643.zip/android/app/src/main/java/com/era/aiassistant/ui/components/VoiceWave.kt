package com.era.aiassistant.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * Animated equalizer bars shown while ERA is listening.
 */
@Composable
fun VoiceWave(
    active: Boolean,
    color: Color,
    modifier: Modifier = Modifier,
    bars: Int = 5
) {
    val transition = rememberInfiniteTransition(label = "wave")
    Row(
        modifier = modifier.height(48.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        repeat(bars) { index ->
            val scale by transition.animateFloat(
                initialValue = 0.3f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(500 + index * 120),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "bar$index"
            )
            androidx.compose.foundation.layout.Box(
                modifier = Modifier
                    .width(8.dp)
                    .height(40.dp)
                    .scale(scaleX = 1f, scaleY = if (active) scale else 0.25f)
                    .background(color, RoundedCornerShape(8.dp))
            )
        }
    }
}
