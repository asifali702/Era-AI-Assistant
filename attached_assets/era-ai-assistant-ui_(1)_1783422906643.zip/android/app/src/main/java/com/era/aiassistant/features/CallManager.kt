package com.era.aiassistant.features

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

/**
 * Looks up contacts by name and places phone calls.
 */
class CallManager(private val context: Context) {

    data class Contact(val name: String, val number: String)

    /** Finds the best matching contact number for a spoken name. */
    fun findContactNumber(name: String): Contact? {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) return null

        val resolver = context.contentResolver
        val cursor = resolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            arrayOf(
                ContactsContract.Contacts._ID,
                ContactsContract.Contacts.DISPLAY_NAME,
                ContactsContract.Contacts.HAS_PHONE_NUMBER
            ),
            "${ContactsContract.Contacts.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            "${ContactsContract.Contacts.DISPLAY_NAME} ASC"
        ) ?: return null

        cursor.use {
            while (it.moveToNext()) {
                val id = it.getLong(0)
                val display = it.getString(1) ?: continue
                val hasPhone = it.getInt(2) > 0
                if (!hasPhone) continue

                val phoneCursor = resolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                    "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?",
                    arrayOf(id.toString()),
                    null
                )
                phoneCursor?.use { pc ->
                    if (pc.moveToFirst()) {
                        val number = pc.getString(0)
                        return Contact(display, number)
                    }
                }
            }
        }
        return null
    }

    /** Places a call directly (requires CALL_PHONE permission). */
    fun call(number: String): Boolean {
        return runCatching {
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE)
                == PackageManager.PERMISSION_GRANTED
            ) {
                context.startActivity(intent)
            } else {
                // Fall back to the dialer if we lack the direct-call permission.
                dial(number)
            }
            true
        }.getOrDefault(false)
    }

    /** Opens the dialer pre-filled with the number (no special permission needed). */
    fun dial(number: String): Boolean {
        return runCatching {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        }.getOrDefault(false)
    }
}
