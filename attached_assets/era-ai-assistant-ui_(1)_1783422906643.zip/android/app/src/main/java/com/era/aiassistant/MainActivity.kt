package com.era.aiassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.era.aiassistant.ui.screens.HomeScreen
import com.era.aiassistant.ui.screens.ListeningScreen
import com.era.aiassistant.ui.screens.SettingsScreen
import com.era.aiassistant.ui.screens.SplashScreen
import com.era.aiassistant.ui.theme.ERAAIAssistantTheme
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState

enum class Screen { SPLASH, HOME, LISTENING, SETTINGS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var darkMode by remember { mutableStateOf(false) }
            ERAAIAssistantTheme(darkTheme = darkMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    EraApp(darkMode = darkMode, onDarkModeChange = { darkMode = it })
                }
            }
        }
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
private fun EraApp(darkMode: Boolean, onDarkModeChange: (Boolean) -> Unit) {
    val context = LocalContext.current
    val controller = remember { AssistantController(context) }
    var screen by remember { mutableStateOf(Screen.SPLASH) }

    DisposableEffect(Unit) {
        onDispose { controller.dispose() }
    }

    val permissions = rememberMultiplePermissionsState(
        listOf(
            android.Manifest.permission.RECORD_AUDIO,
            android.Manifest.permission.CALL_PHONE,
            android.Manifest.permission.READ_CONTACTS,
            android.Manifest.permission.CAMERA
        )
    )

    fun startVoice() {
        if (permissions.allPermissionsGranted) {
            screen = Screen.LISTENING
            controller.startListening()
        } else {
            permissions.launchMultiplePermissionRequest()
        }
    }

    Crossfade(targetState = screen, animationSpec = tween(400), label = "screen") { current ->
        when (current) {
            Screen.SPLASH -> SplashScreen(onFinished = { screen = Screen.HOME })

            Screen.HOME -> HomeScreen(
                torchOn = controller.torchOn,
                onMicTap = { startVoice() },
                onSettings = { screen = Screen.SETTINGS },
                onCall = { startVoice() },
                onWhatsApp = { controller.openWhatsApp() },
                onTorch = {
                    if (permissions.allPermissionsGranted) controller.toggleTorch()
                    else permissions.launchMultiplePermissionRequest()
                },
                onAlarm = { controller.quickAlarm(7, 0) }
            )

            Screen.LISTENING -> ListeningScreen(
                status = controller.status,
                partialText = controller.partialText,
                transcript = controller.transcript,
                response = controller.response,
                onMicTap = { controller.startListening() },
                onClose = {
                    controller.cancel()
                    screen = Screen.HOME
                }
            )

            Screen.SETTINGS -> SettingsScreen(
                darkMode = darkMode,
                onDarkModeChange = onDarkModeChange,
                onBack = { screen = Screen.HOME }
            )
        }
    }
}
