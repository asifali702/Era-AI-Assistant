package com.era.aiassistant.ui.theme

import androidx.compose.ui.graphics.Color

// Premium blue & white palette
val EraBlue = Color(0xFF2563EB)
val EraBlueDark = Color(0xFF1D4ED8)
val EraBlueLight = Color(0xFF60A5FA)
val EraSky = Color(0xFFDBEAFE)
val EraBackground = Color(0xFFF5F8FF)
val EraSurface = Color(0xFFFFFFFF)
val EraOnSurface = Color(0xFF16213E)
val EraMuted = Color(0xFF64748B)
val EraWhite = Color(0xFFFFFFFF)

// Dark theme surfaces
val Color0F172A = Color(0xFF0F172A)
val Color1E293B = Color(0xFF1E293B)

// Feature accent colors
val CallGreen = Color(0xFF22C55E)
val WhatsAppGreen = Color(0xFF25D366)
val TorchAmber = Color(0xFFF59E0B)
val AlarmIndigo = Color(0xFF6366F1)
