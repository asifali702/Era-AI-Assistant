package com.era.aiassistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.era.aiassistant.VoiceStatus
import com.era.aiassistant.ui.components.GlowingMicButton
import com.era.aiassistant.ui.components.VoiceWave

@Composable
fun ListeningScreen(
    status: VoiceStatus,
    partialText: String,
    transcript: String,
    response: String,
    onMicTap: () -> Unit,
    onClose: () -> Unit
) {
    val statusLabel = when (status) {
        VoiceStatus.LISTENING -> "Listening..."
        VoiceStatus.PROCESSING -> "Thinking..."
        VoiceStatus.SPEAKING -> "Speaking..."
        VoiceStatus.IDLE -> "Tap to speak"
    }
    val displayText = when {
        transcript.isNotBlank() -> transcript
        partialText.isNotBlank() -> partialText
        else -> statusLabel
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.primary,
                        MaterialTheme.colorScheme.primaryContainer
                    )
                )
            )
    ) {
        IconButton(
            onClick = onClose,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Close,
                contentDescription = "Close",
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(28.dp)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = statusLabel,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
            )
            Box(modifier = Modifier.padding(vertical = 32.dp)) {
                GlowingMicButton(
                    active = status == VoiceStatus.LISTENING,
                    onClick = onMicTap
                )
            }
            VoiceWave(
                active = status == VoiceStatus.LISTENING || status == VoiceStatus.SPEAKING,
                color = MaterialTheme.colorScheme.onPrimary
            )

            Text(
                text = displayText,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 40.dp)
            )

            if (response.isNotBlank() && status != VoiceStatus.LISTENING) {
                Surface(
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 24.dp)
                ) {
                    Text(
                        text = response,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onPrimary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(18.dp)
                    )
                }
            }
        }
    }
}
