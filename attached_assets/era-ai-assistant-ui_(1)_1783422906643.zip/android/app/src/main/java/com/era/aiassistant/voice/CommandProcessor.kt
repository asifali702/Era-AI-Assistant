package com.era.aiassistant.voice

import com.era.aiassistant.features.AlarmScheduler
import com.era.aiassistant.features.CallManager
import com.era.aiassistant.features.FlashlightController
import com.era.aiassistant.features.WhatsAppManager
import java.util.Locale

/**
 * Parses a spoken command and executes the matching feature.
 * Returns a spoken response string for TextToSpeech.
 */
class CommandProcessor(
    private val flashlight: FlashlightController,
    private val callManager: CallManager,
    private val whatsApp: WhatsAppManager,
    private val alarm: AlarmScheduler,
    private val onTorchChanged: (Boolean) -> Unit
) {

    fun process(raw: String): String {
        val text = raw.trim().lowercase(Locale.getDefault())
        if (text.isBlank()) return "I didn't hear anything. Please try again."

        return when {
            isTorchOn(text) -> handleTorch(true)
            isTorchOff(text) -> handleTorch(false)
            isWhatsApp(text) -> handleWhatsApp(text)
            isCall(text) -> handleCall(text)
            isAlarm(text) -> handleAlarm(text)
            isTimer(text) -> handleTimer(text)
            else -> "Sorry, I can't do that yet. Try: turn on the torch, call a contact, " +
                "open WhatsApp, or set an alarm."
        }
    }

    // ---- Matchers ----
    private fun isTorchOn(t: String) =
        (t.contains("torch") || t.contains("flashlight") || t.contains("light")) &&
            (t.contains("on") || t.contains("enable") || t.contains("turn up"))

    private fun isTorchOff(t: String) =
        (t.contains("torch") || t.contains("flashlight") || t.contains("light")) &&
            (t.contains("off") || t.contains("disable"))

    private fun isWhatsApp(t: String) = t.contains("whatsapp") || t.contains("whats app")
    private fun isCall(t: String) = t.contains("call") || t.contains("dial") || t.contains("phone")
    private fun isAlarm(t: String) = t.contains("alarm") || t.contains("wake me")
    private fun isTimer(t: String) = t.contains("timer") || t.contains("countdown")

    // ---- Handlers ----
    private fun handleTorch(on: Boolean): String {
        if (!flashlight.isAvailable) return "This device has no flashlight."
        val ok = flashlight.setTorch(on)
        if (ok) onTorchChanged(on)
        return if (ok) "Torch turned ${if (on) "on" else "off"}."
        else "I couldn't control the flashlight."
    }

    private fun handleWhatsApp(t: String): String {
        if (!whatsApp.isInstalled()) return "WhatsApp is not installed on this device."
        return if (whatsApp.open()) "Opening WhatsApp." else "I couldn't open WhatsApp."
    }

    private fun handleCall(t: String): String {
        val name = extractContactName(t)
        if (name.isBlank()) return "Who would you like to call?"
        val contact = callManager.findContactNumber(name)
            ?: return "I couldn't find a contact named $name."
        return if (callManager.call(contact.number)) "Calling ${contact.name}."
        else "I couldn't place the call."
    }

    private fun handleAlarm(t: String): String {
        val time = extractTime(t)
        return if (time != null && alarm.setAlarm(time.first, time.second)) {
            "Alarm set for ${formatTime(time.first, time.second)}."
        } else if (alarm.setAlarm(defaultHour(t), 0)) {
            "Opening the clock to set your alarm."
        } else {
            "I couldn't set the alarm."
        }
    }

    private fun handleTimer(t: String): String {
        val seconds = extractDurationSeconds(t) ?: 300
        return if (alarm.setTimer(seconds)) "Timer set for ${seconds / 60} minutes."
        else "I couldn't set the timer."
    }

    // ---- Parsing helpers ----
    private fun extractContactName(t: String): String {
        // "call john", "dial mom", "phone alex now"
        val cleaned = t.replace(Regex("\\b(call|dial|phone|please|now|contact)\\b"), " ")
        return cleaned.trim().replace(Regex("\\s+"), " ")
    }

    /** Parses "7 30", "7:30", "at 7", "7 am", "7 pm". */
    private fun extractTime(t: String): Pair<Int, Int>? {
        val isPm = t.contains("pm") || t.contains("evening") || t.contains("night")
        val isAm = t.contains("am") || t.contains("morning")

        val colon = Regex("(\\d{1,2}):(\\d{2})").find(t)
        if (colon != null) {
            var h = colon.groupValues[1].toInt()
            val m = colon.groupValues[2].toInt()
            if (isPm && h < 12) h += 12
            if (isAm && h == 12) h = 0
            return h to m
        }

        val single = Regex("\\bat\\s+(\\d{1,2})\\b").find(t)
            ?: Regex("\\b(\\d{1,2})\\s*(?:am|pm|o'clock|oclock)").find(t)
        if (single != null) {
            var h = single.groupValues[1].toInt()
            if (isPm && h < 12) h += 12
            if (isAm && h == 12) h = 0
            return h to 0
        }
        return null
    }

    private fun defaultHour(t: String) = if (t.contains("pm")) 19 else 7

    /** Parses "5 minute", "30 second", "1 hour" into seconds. */
    private fun extractDurationSeconds(t: String): Int? {
        Regex("(\\d+)\\s*hour").find(t)?.let { return it.groupValues[1].toInt() * 3600 }
        Regex("(\\d+)\\s*min").find(t)?.let { return it.groupValues[1].toInt() * 60 }
        Regex("(\\d+)\\s*sec").find(t)?.let { return it.groupValues[1].toInt() }
        return null
    }

    private fun formatTime(h: Int, m: Int): String {
        val suffix = if (h >= 12) "PM" else "AM"
        val hour12 = when {
            h == 0 -> 12
            h > 12 -> h - 12
            else -> h
        }
        return "%d:%02d %s".format(hour12, m, suffix)
    }
}
