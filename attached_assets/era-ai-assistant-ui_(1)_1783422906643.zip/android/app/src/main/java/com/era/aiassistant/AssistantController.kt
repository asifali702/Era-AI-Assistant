package com.era.aiassistant

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.era.aiassistant.features.AlarmScheduler
import com.era.aiassistant.features.CallManager
import com.era.aiassistant.features.FlashlightController
import com.era.aiassistant.features.WhatsAppManager
import com.era.aiassistant.voice.CommandProcessor
import com.era.aiassistant.voice.SpeechRecognizerManager
import com.era.aiassistant.voice.TextToSpeechManager

enum class VoiceStatus { IDLE, LISTENING, PROCESSING, SPEAKING }

/**
 * Central orchestrator: wires speech input -> command processing -> feature actions -> TTS output.
 * Exposes Compose-observable state for the UI.
 */
class AssistantController(context: Context) {

    private val appContext = context.applicationContext

    // ---- Observable UI state ----
    var status by mutableStateOf(VoiceStatus.IDLE)
        private set
    var partialText by mutableStateOf("")
        private set
    var transcript by mutableStateOf("")
        private set
    var response by mutableStateOf("Tap the mic and tell me what to do.")
        private set
    var torchOn by mutableStateOf(false)
        private set
    var errorMessage by mutableStateOf<String?>(null)
        private set

    // ---- Feature controllers ----
    private val flashlight = FlashlightController(appContext)
    private val callManager = CallManager(appContext)
    private val whatsApp = WhatsAppManager(appContext)
    private val alarm = AlarmScheduler(appContext)

    private val tts = TextToSpeechManager(
        context = appContext,
        onStart = { status = VoiceStatus.SPEAKING },
        onDone = { if (status == VoiceStatus.SPEAKING) status = VoiceStatus.IDLE }
    )

    private val commandProcessor = CommandProcessor(
        flashlight = flashlight,
        callManager = callManager,
        whatsApp = whatsApp,
        alarm = alarm,
        onTorchChanged = { torchOn = it }
    )

    private val speech = SpeechRecognizerManager(
        context = appContext,
        onReadyForSpeech = {
            status = VoiceStatus.LISTENING
            errorMessage = null
            partialText = ""
        },
        onPartial = { partialText = it },
        onResult = { handleResult(it) },
        onError = { handleError(it) },
        onEnd = { if (status == VoiceStatus.LISTENING) status = VoiceStatus.PROCESSING }
    )

    val isSpeechAvailable: Boolean get() = speech.isAvailable
    val isTorchAvailable: Boolean get() = flashlight.isAvailable

    // ---- Public actions ----
    fun startListening() {
        errorMessage = null
        transcript = ""
        partialText = ""
        response = "Listening..."
        status = VoiceStatus.LISTENING
        speech.start()
    }

    fun stopListening() {
        speech.stop()
    }

    fun cancel() {
        speech.cancel()
        status = VoiceStatus.IDLE
        partialText = ""
    }

    fun toggleTorch() {
        val next = !torchOn
        if (flashlight.setTorch(next)) {
            torchOn = next
            speak(if (next) "Torch on." else "Torch off.")
        }
    }

    fun openWhatsApp() {
        val msg = if (whatsApp.open()) "Opening WhatsApp." else "WhatsApp is not available."
        speak(msg)
    }

    fun quickAlarm(hour: Int, minute: Int) {
        val ok = alarm.setAlarm(hour, minute, "ERA Alarm")
        speak(if (ok) "Alarm scheduled." else "Couldn't set the alarm.")
    }

    fun runCommand(text: String) = handleResult(text)

    // ---- Internal ----
    private fun handleResult(text: String) {
        transcript = text
        partialText = ""
        status = VoiceStatus.PROCESSING
        val reply = commandProcessor.process(text)
        response = reply
        speak(reply)
    }

    private fun handleError(message: String) {
        errorMessage = message
        response = message
        status = VoiceStatus.IDLE
    }

    private fun speak(text: String) {
        response = text
        status = VoiceStatus.SPEAKING
        tts.speak(text)
    }

    fun dispose() {
        speech.destroy()
        tts.shutdown()
    }
}
