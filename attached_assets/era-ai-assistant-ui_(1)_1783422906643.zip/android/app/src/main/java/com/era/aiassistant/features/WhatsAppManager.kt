package com.era.aiassistant.features

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Opens WhatsApp, optionally to a specific chat / message.
 */
class WhatsAppManager(private val context: Context) {

    private val packages = listOf("com.whatsapp", "com.whatsapp.w4b")

    fun isInstalled(): Boolean = packages.any { pkg ->
        runCatching { context.packageManager.getLaunchIntentForPackage(pkg) != null }
            .getOrDefault(false)
    }

    /** Opens the WhatsApp app. */
    fun open(): Boolean {
        val pkg = packages.firstOrNull {
            context.packageManager.getLaunchIntentForPackage(it) != null
        } ?: return false
        val intent = context.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { context.startActivity(intent); true }.getOrDefault(false)
    }

    /** Sends a message to a phone number via WhatsApp (opens the chat with prefilled text). */
    fun sendMessage(phoneNumber: String, message: String = ""): Boolean {
        val normalized = phoneNumber.filter { it.isDigit() }
        val uri = Uri.parse(
            "https://wa.me/$normalized" + if (message.isNotBlank())
                "?text=${Uri.encode(message)}" else ""
        )
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return runCatching { context.startActivity(intent); true }
            .getOrElse {
                // Retry without forcing the package (lets the user pick WhatsApp Business).
                runCatching {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                    true
                }.getOrDefault(false)
            }
    }
}
