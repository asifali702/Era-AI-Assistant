package com.era.aiassistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.era.aiassistant.ui.theme.AlarmIndigo
import com.era.aiassistant.ui.theme.CallGreen
import com.era.aiassistant.ui.theme.TorchAmber
import com.era.aiassistant.ui.theme.WhatsAppGreen

@Composable
fun SettingsScreen(
    darkMode: Boolean,
    onDarkModeChange: (Boolean) -> Unit,
    onBack: () -> Unit
) {
    var callEnabled by remember { mutableStateOf(true) }
    var whatsAppEnabled by remember { mutableStateOf(true) }
    var torchEnabled by remember { mutableStateOf(true) }
    var alarmEnabled by remember { mutableStateOf(true) }
    var voiceFeedback by remember { mutableStateOf(true) }
    var wakeWord by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
            Text(
                text = "Settings",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(start = 4.dp)
            )
        }

        SectionTitle("Features")
        SettingsCard {
            ToggleRow(Icons.Filled.Call, CallGreen, "Call by voice", callEnabled) { callEnabled = it }
            ToggleRow(Icons.Filled.Chat, WhatsAppGreen, "WhatsApp by voice", whatsAppEnabled) { whatsAppEnabled = it }
            ToggleRow(Icons.Filled.FlashlightOn, TorchAmber, "Flashlight control", torchEnabled) { torchEnabled = it }
            ToggleRow(Icons.Filled.Alarm, AlarmIndigo, "Set alarms", alarmEnabled) { alarmEnabled = it }
        }

        SectionTitle("Voice")
        SettingsCard {
            ToggleRow(Icons.Filled.RecordVoiceOver, MaterialTheme.colorScheme.primary, "Spoken replies (TTS)", voiceFeedback) { voiceFeedback = it }
            ToggleRow(Icons.Filled.Mic, MaterialTheme.colorScheme.primary, "\"Hey ERA\" wake word", wakeWord) { wakeWord = it }
        }

        SectionTitle("Appearance")
        SettingsCard {
            ToggleRow(Icons.Filled.DarkMode, MaterialTheme.colorScheme.primary, "Dark mode", darkMode) { onDarkModeChange(it) }
        }

        Text(
            text = "ERA AI Assistant • v1.0",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 24.dp),
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 24.dp, bottom = 10.dp, start = 4.dp)
    )
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(vertical = 6.dp)) { content() }
    }
}

@Composable
private fun ToggleRow(
    icon: ImageVector,
    accent: Color,
    label: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(accent.copy(alpha = 0.14f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = label, tint = accent, modifier = Modifier.size(20.dp))
            }
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(start = 14.dp)
            )
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
