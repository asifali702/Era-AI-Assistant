package com.era.aiassistant.features

import android.content.Context
import android.hardware.camera2.CameraManager

/**
 * Controls the device flashlight (torch) using Camera2 API.
 */
class FlashlightController(context: Context) {

    private val cameraManager =
        context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    private val cameraId: String? = runCatching {
        cameraManager.cameraIdList.firstOrNull { id ->
            cameraManager.getCameraCharacteristics(id)
                .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
    }.getOrNull()

    val isAvailable: Boolean get() = cameraId != null

    fun setTorch(enabled: Boolean): Boolean {
        val id = cameraId ?: return false
        return runCatching {
            cameraManager.setTorchMode(id, enabled)
            true
        }.getOrDefault(false)
    }
}
