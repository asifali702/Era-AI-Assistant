package com.era.aiassistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.era.aiassistant.ui.components.FeatureCard
import com.era.aiassistant.ui.components.GlowingMicButton
import com.era.aiassistant.ui.theme.AlarmIndigo
import com.era.aiassistant.ui.theme.CallGreen
import com.era.aiassistant.ui.theme.TorchAmber
import com.era.aiassistant.ui.theme.WhatsAppGreen

@Composable
fun HomeScreen(
    torchOn: Boolean,
    onMicTap: () -> Unit,
    onSettings: () -> Unit,
    onCall: () -> Unit,
    onWhatsApp: () -> Unit,
    onTorch: () -> Unit,
    onAlarm: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Hello there",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "ERA Assistant",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
            IconButton(onClick = onSettings) {
                Icon(
                    imageVector = Icons.Filled.Settings,
                    contentDescription = "Settings",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
            }
        }

        // Glowing mic
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            GlowingMicButton(active = true, onClick = onMicTap)
        }

        Text(
            text = "Tap to speak",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground,
            fontWeight = FontWeight.SemiBold
        )
        Text(
            text = "\"Call Mom\"  •  \"Open WhatsApp\"  •  \"Set alarm at 7\"",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
        )

        // Feature grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            FeatureCard(
                label = "Call",
                subtitle = "Dial a contact",
                icon = Icons.Filled.Call,
                accent = CallGreen,
                onClick = onCall,
                modifier = Modifier.weight(1f)
            )
            FeatureCard(
                label = "WhatsApp",
                subtitle = "Open chats",
                icon = Icons.Filled.Chat,
                accent = WhatsAppGreen,
                onClick = onWhatsApp,
                modifier = Modifier.weight(1f)
            )
        }
        androidx.compose.foundation.layout.Spacer(modifier = Modifier.size(14.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            FeatureCard(
                label = if (torchOn) "Torch On" else "Torch",
                subtitle = "Toggle flashlight",
                icon = Icons.Filled.FlashlightOn,
                accent = TorchAmber,
                onClick = onTorch,
                modifier = Modifier.weight(1f)
            )
            FeatureCard(
                label = "Alarm",
                subtitle = "Set a wake up",
                icon = Icons.Filled.Alarm,
                accent = AlarmIndigo,
                onClick = onAlarm,
                modifier = Modifier.weight(1f)
            )
        }
    }
}
