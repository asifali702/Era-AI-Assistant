# ERA AI Assistant — Android (Kotlin + Jetpack Compose)

A premium blue & white, Material 3 voice assistant app. This is a complete, native
Android Studio project. It does **not** run in the web preview — download it and open
it in Android Studio.

## Features

- **Voice recognition** — `SpeechRecognizerManager` (Android `SpeechRecognizer`) with live partial results.
- **Text-to-speech replies** — `TextToSpeechManager` speaks every response.
- **Call by voice** — "call mom" / "dial alex" → looks up the contact and places the call.
- **Open WhatsApp by voice** — "open whatsapp" launches the app.
- **Flashlight ON/OFF** — "turn on the torch" toggles the camera flash.
- **Set alarm by voice** — "set alarm at 7:30 am" opens the system clock alarm; "set a 5 minute timer" starts a timer.
- **Runtime permissions** — RECORD_AUDIO, CALL_PHONE, READ_CONTACTS, CAMERA (SET_ALARM is normal).

## Screens

1. **Splash** — animated logo + progress, auto-advances.
2. **Home** — large glowing microphone + Call / WhatsApp / Torch / Alarm tiles.
3. **Voice Listening** — full-blue immersive state with animated waveform and transcript.
4. **Settings** — feature toggles, voice options, and dark mode.

## Project structure

```
app/src/main/java/com/era/aiassistant/
├── MainActivity.kt              # Navigation (Crossfade) + permission requests
├── AssistantController.kt       # Orchestrates speech -> command -> action -> TTS (Compose state)
├── voice/
│   ├── SpeechRecognizerManager.kt
│   ├── TextToSpeechManager.kt
│   └── CommandProcessor.kt      # Parses spoken text into feature actions
├── features/
│   ├── FlashlightController.kt
│   ├── CallManager.kt
│   ├── WhatsAppManager.kt
│   └── AlarmScheduler.kt
└── ui/
    ├── theme/                   # Material 3 blue theme, typography
    ├── components/              # GlowingMicButton, FeatureCard, VoiceWave
    └── screens/                 # Splash, Home, Listening, Settings
```

## Build & run

1. Open the `android/` folder in **Android Studio** (Ladybug or newer).
2. Let Gradle sync. Android Studio will provision the Gradle wrapper if needed.
3. Run on a **physical device** (voice recognition, calling, and flashlight need real hardware).
4. Grant the microphone, phone, contacts, and camera permissions when prompted.

### Requirements
- Android Studio (AGP 8.7.x), JDK 17
- `compileSdk` / `targetSdk` 35, `minSdk` 24
- Kotlin 2.0.21, Compose BOM 2024.10.01

## Voice command examples

| Say | Action |
|-----|--------|
| "Turn on the torch" / "flashlight off" | Toggle flashlight |
| "Call Mom" / "Dial Alex" | Find contact + call |
| "Open WhatsApp" | Launch WhatsApp |
| "Set alarm at 7:30 am" | Create system alarm |
| "Set a 5 minute timer" | Start a timer |
